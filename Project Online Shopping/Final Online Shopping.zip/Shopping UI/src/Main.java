import shopping.ui.UI;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        new UI().setVisible(true);
    }
}
